from fastapi import APIRouter
from fastapi.responses import StreamingResponse
from io import BytesIO

from backend.admin.admin_service import (
    get_dashboard_summary,
    get_table_data,
    create_excel_file
)


# ============================================
# Admin Router
# ============================================

router = APIRouter(
    prefix="/admin",
    tags=["Admin"]
)


# ============================================
# Dashboard Summary
# ============================================

@router.get("/dashboard")
def dashboard():

    return get_dashboard_summary()


# ============================================
# Registrations
# ============================================

@router.get("/registrations")
def registrations():

    columns, rows = get_table_data(
        "registrations"
    )

    return {
        "columns": columns,
        "data": rows
    }


# ============================================
# Cultural Registrations
# ============================================

@router.get("/cultural")
def cultural():

    columns, rows = get_table_data(
        "cultural"
    )

    return {
        "columns": columns,
        "data": rows
    }


# ============================================
# Volunteers
# ============================================

@router.get("/volunteers")
def volunteers():

    columns, rows = get_table_data(
        "volunteers"
    )

    return {
        "columns": columns,
        "data": rows
    }


# ============================================
# Donations
# ============================================

@router.get("/donations")
def donations():

    columns, rows = get_table_data(
        "donations"
    )

    return {
        "columns": columns,
        "data": rows
    }


# ============================================
# Annaprasada
# ============================================

@router.get("/annaprasada")
def annaprasada():

    columns, rows = get_table_data(
        "annaprasada"
    )

    return {
        "columns": columns,
        "data": rows
    }


# ============================================
# Export ALL Data to Excel
# ============================================

@router.get("/export/all")
def export_all():

    workbook = create_excel_file()

    output = BytesIO()

    workbook.save(output)

    output.seek(0)

    return StreamingResponse(
        output,
        media_type=(
            "application/vnd.openxmlformats-"
            "officedocument.spreadsheetml.sheet"
        ),
        headers={
            "Content-Disposition":
                "attachment; "
                "filename=LVS_Festival_Data.xlsx"
        }
    )